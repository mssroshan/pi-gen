==============================
POS Auto Send Mail – Odoo 18
============================

.. image:: banner.png
:alt: Bank Details in Sale and invoice Reports
:align: center


This module helps businesses clearly communicate their bank details
by automatically printing company banking information on invoices and sales reports,
making customer payments faster and more accurate.